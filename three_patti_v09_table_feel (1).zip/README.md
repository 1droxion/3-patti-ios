# 3 Patti Social V0.9 — Table Feel + Turn Reliability

Drop-in update for the existing `3-patti-ios` repo. It does not overwrite the `ios/` folder or Apple signing configuration.

## V0.9 changes
- Dealer now visibly deals cards toward every player seat at the start of a hand.
- Turn countdown is attached to the active player's profile ring/badge, not the dealer.
- 60-second timeout is server authoritative; after timeout the next active player gets the turn.
- App refreshes/synchronizes immediately after returning from notifications, Control Center, a phone interruption, or background/resume.
- Server timestamp is used to keep the countdown aligned after resume.
- Table balances now show CHIPS only; rupee symbols were removed from the gameplay/wallet prototype UI.
- Pot uses colorful casino-chip stacks.
- Betting chips animate from the acting player to the center pot.
- Blind players use BLIND at the same base stake.
- After Seen Card, the primary betting button automatically becomes CHAAL at 2x the blind stake.
- Other players can see BLIND / SEEN / PACKED status, but never another player's private cards before showdown.
- Bottom action dock redesigned: BLIND/CHAAL, SEEN CARD, PACK, SHOW, SIDE SHOW.
- Card flip/deal animation, chip sound, card sound, win sound and haptics retained/improved.
- Prototype deck shuffle upgraded from Math.random to Node crypto.randomInt. This is stronger prototype randomness but is not a substitute for regulated RNG certification.
- Version 0.9.0+10.

## Install
```bash
cd /workspaces/3-patti-ios
unzip -o three_patti_v09_table_feel.zip
rm three_patti_v09_table_feel.zip
flutter pub get
git add .
git commit -m "Improve Teen Patti table v0.9"
git push
```

## Important multiplayer note
The current Vercel backend still stores rooms in process memory. That is acceptable for prototype testing but can be unreliable for real live multiplayer because serverless instances can restart or split traffic. Before production/cash play, move rooms/turns/wallet state to a persistent realtime backend or dedicated game server.
